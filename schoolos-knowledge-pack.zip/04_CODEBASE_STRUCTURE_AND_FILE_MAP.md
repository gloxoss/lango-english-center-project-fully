# 📁 Codebase Structure & File Map

## 1. Directory Tree Overview

```
lango-english-center-project-fully/
├── docker-compose.yml          # Production multi-container composition
├── deploy-vps.bat              # One-click Windows deployment trigger
├── AGENTS.md                   # AI Agent Ground Truth & Operational Rules
├── schoolos-knowledge-pack/    # Standalone System Context & Agent Dossier
└── lango-app/                  # Main Next.js 15 Application Root
    ├── package.json            # Dependencies & build scripts
    ├── next.config.ts          # Next.js config (standalone build, 308 redirects)
    ├── drizzle.config.ts       # Drizzle ORM configuration
    ├── Dockerfile              # Multi-stage Linux/AMD64 production container build
    ├── migrations/             # 145+ sequential SQL database migration files
    ├── scripts/
    │   ├── deploy-to-vps.ps1   # PowerShell automated zero-downtime VPS deployment
    │   ├── check-ui-reality.ts # UI Reality ratchet analysis tool
    │   └── check-tenant-isolation.ts # Static multi-tenant safety auditor
    └── src/
        ├── app/                # Next.js App Router (Pages & API endpoints)
        ├── components/         # Reusable design system UI primitives
        ├── features/           # Bounded context feature domains
        ├── libs/               # Cross-cutting platform libraries & utilities
        ├── models/             # Drizzle database schemas & types
        └── locales/            # Translation dictionaries (ar, fr, en)
```

---

## 2. Source Code Architecture (`src/`)

### 2.1 The Next.js App Router (`src/app/`)
- **`[locale]/(auth)/`**: Login, registration, password reset, and session recovery screens.
- **`[locale]/(dashboard)/dashboard/`**:
  - `academics/`: Timetable, classes, sections, rooms, exams, marksheet.
  - `students/`: Directory, admissions, matricules, photo grid, promotions.
  - `finance/`: Invoicing, cashier sessions, online payments, Moroccan accounting.
  - `hr/`: Employee directory, contracts, leave management.
  - `workforce/`: Timeclock kiosk, Moroccan CNSS/IR payroll engine.
  - `communication/`:
    - `reminders/` (Canonical Reminders Hub, with permanent 308 redirect from `sms-reminders`).
    - `broadcast/`: Broadcast campaigns and outbound connectors.
  - `transport/`: Fleet routes, stops, and allocations.
  - `super-admin/`: Platform owner multi-school console.
- **`api/`**: 798+ RESTful API endpoints organized symmetrically by feature module.

### 2.2 Feature Modules (`src/features/`)
Each feature module encapsulates its own UI views, client controllers, domain services, models, and tests:
- `academics/`: `services/room-registry.ts`, `services/massar-sync-service.ts`, `ui/exam-planning-client.tsx`.
- `assessment/`: `services/homework-service.ts`, `services/teacher-question-bank-service.ts`, `ui/marksheet-grid-view.tsx`.
- `broadcast/`:
  - `providers/`: Concrete adapters (`whatsapp-waha-provider.ts`, `android-sms-provider.ts`, `smsto-provider.ts`, `twilio-sms-provider.ts`, `resend-email-provider.ts`, `brevo-email-provider.ts`).
  - `services/`: `whatsapp-anti-spam-service.ts` (Daily quota engine, anti-ban pacing), `sms-delivery.ts` (Multi-channel router), `connections-service.ts`.
  - `ui/`: `connections-view.tsx` (QR Code pairing modal, test dispatches).
- `communication/`: `ui/sms-reminders-view.tsx` (Interactive multi-channel dispatch hub).
- `finance/`: `ui/invoices-view.tsx`, `ui/cashier-sessions-view.tsx`, `ui/journal-explorer-view.tsx`.
- `workforce/`: `services/payroll-engine.ts`, `services/ma-regulation-adapter.ts` (Moroccan labor laws & tax formulas).

### 2.3 Shared Primitives (`src/components/`)
- `ui/`: Radix-powered, Tailwind-styled primitives (`button.tsx`, `badge.tsx`, `card.tsx`, `dialog.tsx`, `input.tsx`, `select.tsx`, `tabs.tsx`).
- `shared/`: App headers, tenant switchers, sidebars, navigation drawers, and global breadcrumbs.

### 2.4 Platform Libraries (`src/libs/`)
- **`api/context.ts`**: Authentication pipeline. Validates Bearer token or session cookie, resolves tenant context, checks capabilities (`requireRequestContext`, `requireTenant`, `requireCapability`).
- **`api/errors.ts`**: Standardized `ApiError` class (HTTP status, error code, friendly message) and `apiErrorResponse()` handler.
- **`api/validation.ts`**: Centralized Zod request validation schemas (`smsMessageCreateSchema`, `studentCreateSchema`, etc.) enforcing `.strict()`.
- **`api/audit.ts`**: Law 09-08 compliant audit logger (`recordAudit`).
- **`DB.ts`**: Drizzle client connection singleton connected to PostgreSQL pool.
- **`sms/gsm7.ts`**: Moroccan GSM-7 character analysis, accent substitution, and segment calculator.

---

## 3. State Management & Component Conventions

1. **Server vs. Client Components**:
   - Page files (`page.tsx`) act as lightweight server wrappers handling metadata, i18n locale loading, and SSR pre-fetching.
   - Interactive logic is delegated to corresponding client views (`page.client.tsx` or `*Client.tsx`, `*View.tsx`) tagged with `'use client'`.
2. **URL State as the Single Source of Truth**:
   - Filtering, search queries, pagination (`page`, `pageSize`), and active tabs are stored in URL query parameters (`searchParams`) for instant shareability and browser back-button fidelity.
3. **Optimistic Feedback**:
   - Fast state toggles (like Primary/Emergency contact switches or row selections) update client state optimistically and reconcile via background fetch.
