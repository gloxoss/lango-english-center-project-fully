# 🗺️ Roadmap & Target Objectives

## 1. Production Achievements (Currently Live)

SchoolOS is currently operating live in production on VPS `43.157.17.129` (`https://schoolos.epioso.com`). The following milestones are fully completed, tested, and active:

- ✅ **Full Multi-Tenancy Architecture**: Complete database row-level partitioning with strict static analysis gates.
- ✅ **Moroccan Regulatory Compliance**:
  - Official Moroccan **/20 grading engine** with Filière-specific subject coefficients.
  - Moroccan Labor & Tax engine: Statutory **CNSS (6 000 DH cap)**, AMO withholding, progressive **IR tax brackets**, and family dependent abatements.
  - **Massar System Integration**: Import/export compatibility with Ministry of National Education rosters and marksheets.
  - **GSM-7 SMS Direct Engine**: Moroccan carrier character normalization and credit simulation.
- ✅ **WhatsApp Multi-Session & Meta Anti-Ban Protection**:
  - Automatic per-school session isolation (`tenant_{tenantId}`) on the WAHA gateway.
  - Tiered daily quotas (Trial: 25, Basic: 50, Standard: 100, Premium: 250 msg/day).
  - 1 200 ms pacing delay between dispatches.
  - Automatic cut-off (HTTP 429) to prevent bulk spam and phone number bans.
- ✅ **Multi-Channel Reminders Hub**:
  - Filter by "Élèves à risque" (absences/impayés) vs "Tous les élèves".
  - 1-click preset templates (Absence injustifiée, Retard, Rappel scolarité, Convocation).
  - Personal smartphone test dispatch modal.
- ✅ **Document Studio & Official School Seal**:
  - Circular bilingual school stamp (Cachet Officiel) generator matching Ministry standards.
  - Attestation d'inscription, Certificat de scolarité, Bulletins scolaires.
- ✅ **Custom Domains & Automated TLS**:
  - Dynamic on-demand SSL certificate generation via Caddy reverse proxy.
- ✅ **Super Admin Multi-School Console**:
  - School tenant provisioning, subscription plan management, feature entitlement toggling.

---

## 2. Active Backlog & Next Target Milestones

The following features represent the next high-priority development objectives:

### Phase 1: High-Priority Operational Enhancements
1. **Interactive Timetable Drag-and-Drop Grid**:
   - Modernize `/dashboard/academics/schedule` with an interactive HTML5 drag-and-drop slot solver with real-time teacher and room collision warnings.
2. **CMI Moroccan Gateway Live Merchant Credentials Wizard**:
   - Self-service portal interface for schools to upload their Centre Monétique Interbancaire (CMI) production merchant certificates (`cert.pem`, `key.pem`) for online card processing.
3. **Automated Massar Roster Synchronization Cron**:
   - Background sync job to check and import newly enrolled students from Massar without manual CSV re-upload.

### Phase 2: Engagement & Mobile Experience
1. **Parent & Student Mobile PWA with Web Push Notifications**:
   - Instant push notifications for attendance alerts, exam results, and fee notices directly to iOS/Android home-screen web apps.
2. **Automated WhatsApp Attendance Broadcast Triggers**:
   - Configurable trigger: when homeroom teacher marks a student absent in morning registration, automatically queue a WhatsApp reminder to the primary guardian after 30 minutes.
3. **Advanced Financial Analytics & Treasury Forecasting**:
   - Multi-term cash collection projections based on fee assignment maturity dates.
